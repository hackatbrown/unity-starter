using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Timer : MonoBehaviour
{
	private bool timerStarted;
	private Vector3 ogPosition;
	private float timer;
	public GameObject[] checkpoints = new GameObject[4];
	public bool[] checkpointsPassed;
	public TextMeshProUGUI textGO;
    // Start is called before the first frame update
    void Start()
    {
        timerStarted = false;
        ogPosition = this.transform.position;
        checkpointsPassed = new bool[checkpoints.Length];
        for (int i = 0;i<checkpoints.Length;i++){
        	checkpointsPassed[i] = false;
        }
		timer = 0f;
    }

    // Update is called once per frame
    void Update()
    {
    	if (!timerStarted && ogPosition != this.transform.position) {
    		timerStarted = true;
    	}
    	if(timerStarted){
			if (System.Array.IndexOf(checkpointsPassed,false)<0){
				textGO.text = timer.ToString();
			}
			else {
				timer += Time.deltaTime;
				textGO.text = timer.ToString();
			}	
		}
    }
	void OnTriggerEnter(Collider collision) {
		Debug.Log("enter"+collision.gameObject.name);
			for (int i=0;i<checkpoints.Length;i++) {
				if (checkpoints[i].name == collision.gameObject.name) {
					checkpointsPassed[i] = true;
				}
			}
		}
        
    }
