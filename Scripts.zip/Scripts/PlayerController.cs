using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called before the first frame update
    public Vector3 COMOffset;
    public Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.centerOfMass += COMOffset;
    }
    private float speed = 50.0f;
    private float turnSpeed = 80.0f;
    private float horizontalInput;
    private float verticalInput;
    // Update is called once per frame
    void Update()
    {
        
        horizontalInput = Input.GetAxis("Horizontal");
        verticalInput = Input.GetAxis("Vertical");
        //move the vehicle forward
        transform.Translate(Vector3.forward * Time.deltaTime * speed * verticalInput);
        //turn
        transform.Rotate(Vector3.up,Time.deltaTime * turnSpeed * horizontalInput*verticalInput);
    }
}
